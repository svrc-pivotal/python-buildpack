from mammals import Mammals
