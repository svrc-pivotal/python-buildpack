from setuptools import setup

setup(name='mammals',
      version='0.1',
      description='mammals test package',
      url='http://example.com',
      author='buildpack',
      author_email='buildpack@example.com',
      license='MIT',
      packages=['mammals'],
      zip_safe=False)
